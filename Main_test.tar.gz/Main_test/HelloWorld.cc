/*
-------     Universidad de los Andes      -------
-------      Departamento de Física       -------
-------   Proyecto Joven Investigador     -------
-------  Andrés Felipe García Albarracín  -------
-------    Juan Carlos Sanabria Arenas    -------

Hello world program. Write your c++ program using
Root and/or HepMC libraries

*/

#include <iostream>
// Comment the following lines if you do not need ROOT or HepMC
#include "ROOTFunctions.h"
#include "HepMCFunctions.h"
using namespace std;

int main() {
	cout << "Hola mundo" << endl;
	return 0;
}
